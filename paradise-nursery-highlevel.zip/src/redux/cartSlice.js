import { createSlice } from '@reduxjs/toolkit';

const cartSlice = createSlice({
  name: 'cart',
  initialState: {
    items: [],
    totalQuantity: 0
  },
  reducers: {
    addToCart(state, action) {
      const existing = state.items.find(item => item.id === action.payload.id);
      if (existing) {
        existing.quantity += 1;
      } else {
        state.items.push({ ...action.payload, quantity: 1 });
      }
      state.totalQuantity += 1;
    },
    increment(state, action) {
      const item = state.items.find(i => i.id === action.payload);
      if (item) { item.quantity += 1; state.totalQuantity += 1; }
    },
    decrement(state, action) {
      const item = state.items.find(i => i.id === action.payload);
      if (item && item.quantity > 0) {
        item.quantity -= 1; state.totalQuantity -= 1;
      }
    },
    removeItem(state, action) {
      const item = state.items.find(i => i.id === action.payload);
      if (item) {
        state.totalQuantity -= item.quantity;
        state.items = state.items.filter(i => i.id !== action.payload);
      }
    }
  }
});

export const { addToCart, increment, decrement, removeItem } = cartSlice.actions;
export default cartSlice.reducer;