import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { increment, decrement, removeItem } from '../redux/cartSlice';

function CartPage() {
  const items = useSelector(state => state.cart.items);
  const dispatch = useDispatch();
  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);

  return (
    <div className="cart-page">
      <h2>Your Cart</h2>
      {items.length === 0 ? <p>Cart is empty</p> : (
        <table>
          <thead>
            <tr><th>Name</th><th>Qty</th><th>Price</th><th>Total</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {items.map(item => (
              <tr key={item.id}>
                <td>{item.name}</td>
                <td>
                  <button onClick={() => dispatch(decrement(item.id))}>-</button>
                  {item.quantity}
                  <button onClick={() => dispatch(increment(item.id))}>+</button>
                </td>
                <td>{item.price}</td>
                <td>{item.price * item.quantity}</td>
                <td><button onClick={() => dispatch(removeItem(item.id))}>Remove</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <h3>Total: ₹{total}</h3>
    </div>
  );
}

export default CartPage;