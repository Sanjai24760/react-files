import React from 'react';
import ProductCard from '../components/ProductCard';

const plants = [
  { id: 1, name: 'Snake Plant', category: 'Indoor', price: 300, image: 'https://via.placeholder.com/150' },
  { id: 2, name: 'Aloe Vera', category: 'Medicinal', price: 200, image: 'https://via.placeholder.com/150' },
  { id: 3, name: 'Money Plant', category: 'Climbers', price: 250, image: 'https://via.placeholder.com/150' },
];

function ProductPage() {
  return (
    <div className="product-page">
      <h2>Our Plants</h2>
      <div className="product-list">
        {plants.map(plant => <ProductCard key={plant.id} plant={plant} />)}
      </div>
    </div>
  );
}

export default ProductPage;